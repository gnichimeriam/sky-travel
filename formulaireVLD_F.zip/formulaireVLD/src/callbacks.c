#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"


void
on_button_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char log[50]; char password[50];char hello [50];FILE* f;



GtkWidget *input;
GtkWidget *login1;
GtkWidget *output;
GtkWidget  *listeview;
GtkWidget *login;
GtkWidget *window_formulaire;

login = lookup_widget(objet_graphique,"login");
login1 = lookup_widget(objet_graphique,"entry2");
input=lookup_widget(objet_graphique,"entry3");
output = lookup_widget(objet_graphique, "msg") ;

strcpy(log,gtk_entry_get_text(GTK_ENTRY(login1)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input)));

int x=id_h(log,password,hello);

		if(x==1)
		{

gtk_label_set_text(GTK_LABEL(output),hello);
window_formulaire=create_formulaire();
		gtk_widget_show (window_formulaire);
		gtk_widget_hide(login);



listeview = lookup_widget(window_formulaire,"treeview1");
afficher_agent(listeview);


		}
else

gtk_label_set_text(GTK_LABEL(output),hello);



}
//////////////////////////////////










///////////

void
on_ajouter_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data){
char logs[50],passwords[50],CIN[50],mdp[50], role[50];int x; 
	GtkWidget *input3;
	GtkWidget *input4;	
	GtkWidget *input5;

GtkWidget *input6;
GtkWidget *input7;


	GtkWidget *output;
	GtkWidget *combobox1;
	GtkWidget *formulaire;
	GtkWidget *listeview;

input3=lookup_widget(objet_graphique,"entry10");
input4=lookup_widget(objet_graphique,"entry9");
input5=lookup_widget(objet_graphique,"entry8");

input6=lookup_widget(objet_graphique,"entry11");
//input7=lookup_widget(objet_graphique,"entry12");


combobox1=lookup_widget(objet_graphique,"combobox2");
output=lookup_widget(objet_graphique,"LABEL");

formulaire=lookup_widget(objet_graphique, "formulaire");


strcpy(role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(logs,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(passwords,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(CIN,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(mdp,gtk_entry_get_text(GTK_ENTRY(input6)));

if (strcmp(role,"admin")==0)
		{

 x=ajouter_h(logs,passwords,1,CIN,mdp); 
listeview = lookup_widget(formulaire,"treeview1");
 afficher_agent(listeview);
		}

else if (strcmp(role,"agent")==0)
		{
 x=ajouter_h(logs,passwords,2,CIN,mdp);
listeview = lookup_widget(formulaire,"treeview1");
 afficher_agent(listeview); 
		}

//else if (strcmp(role,"client")==0)
		{
// x=ajouter_h(logs,passwords,3,CIN,mdp);
//listeview = lookup_widget(formulaire,"treeview1"); 
 //afficher_agent(listeview);
		}
if(x==5)
gtk_label_set_text(GTK_LABEL(output),"CIN existe deja");
else if(x==20)
gtk_label_set_text(GTK_LABEL(output),"Compte ajouté");
else if(x==3)
gtk_label_set_text(GTK_LABEL(output),"compte existe deja");
else if(x==0)
gtk_label_set_text(GTK_LABEL(output)," verifier format CIN ");
else if(x==4)
gtk_label_set_text(GTK_LABEL(output)," verifier format CIN ");
else
gtk_label_set_text(GTK_LABEL(output),"ajout avec succes");
}







void
on_supprimer_clicked                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{ 
GtkWidget *input1;
GtkWidget *formulaire;
GtkWidget *listeview;

char cin[50];

formulaire = lookup_widget(objet_graphique,"formulaire");

input1 = lookup_widget(objet_graphique,"entry8");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input1)));
supprimer_h(cin);
listeview = lookup_widget(formulaire,"treeview1");
afficher_agent(listeview); 
}


void
on_modifier_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)

{

GtkWidget *input1;
	GtkWidget *input2;	
	GtkWidget *input3;
GtkWidget *input6;
	GtkWidget *combobox1;

	GtkWidget *listeview;
	GtkWidget *formulaire;

	char login[50],password[50],cin[50],role[50],mdp[50];

	//formulaire = lookup_widget(objet_graphique,"formulaire");
formulaire=lookup_widget(objet_graphique, "formulaire");


input1 = lookup_widget(objet_graphique,"entry10");
input2=lookup_widget(objet_graphique,"entry9");
input3=lookup_widget(objet_graphique,"entry8");
input6=lookup_widget(objet_graphique,"entry11");
combobox1=lookup_widget(objet_graphique,"combobox2");

strcpy(role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(login,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(mdp,gtk_entry_get_text(GTK_ENTRY(input6)));



if (strcmp(role,"admin")==0)
{
modifier_comptes(login,password,1,cin,mdp);
listeview = lookup_widget(formulaire,"treeview1");
afficher_agent(listeview);
}
else if(strcmp(role,"agent")==0)
{
modifier_comptes(login,password,2,cin,mdp);
listeview = lookup_widget(formulaire,"treeview1");
afficher_agent(listeview);
}
else if(strcmp(role,"client")==0)
{
modifier_comptes(login,password,3,cin,mdp);
listeview = lookup_widget(formulaire,"treeview1");
afficher_agent(listeview);
}

}


///////////










void
ad_activated                           (GtkTreeView     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

gint *role;
  	gchar *login;
	gchar *password;
	gchar *cin;
gchar *mdp;   

	GtkWidget *input1;
	GtkWidget *input2;	
	GtkWidget *input3;
	GtkWidget *input4;
	GtkWidget *input5;

GtkWidget *input6;
GtkWidget *input7;
	
GtkWidget *formulaire;
	GtkWidget *listeview;
        
        GtkTreeIter iter;


listeview = lookup_widget(objet_graphique,"treeview1");

GtkTreeModel *model = gtk_tree_view_get_model (GTK_TREE_VIEW(lookup_widget(objet_graphique,"treeview1")));
 

   if (gtk_tree_model_get_iter(model, &iter, path)) {
      gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0, &login, 1, &password,2,&role,3,&cin,4,&mdp, -1);

                                                       }
formulaire = lookup_widget(objet_graphique,"formulaire");

input1 = lookup_widget(formulaire,"entry10");
input2=lookup_widget(formulaire,"entry9");
input3=lookup_widget(formulaire,"entry8");

input6=lookup_widget(formulaire,"entry11");
//input7=lookup_widget(formulaire,"entry12");

input4=lookup_widget(formulaire,"combobox2");

gtk_entry_set_text(GTK_ENTRY(input1),login);
gtk_entry_set_text(GTK_ENTRY(input2),password);
gtk_entry_set_text(GTK_ENTRY(input3),cin);

gtk_entry_set_text(GTK_ENTRY(input6),mdp);

}



