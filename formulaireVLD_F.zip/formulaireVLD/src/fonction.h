int id_h(char log[],char password[], char hello[]);
int ajouter_h(char log[],char password[],int role,char cin[],char mdp[]);
void afficher_agent(GtkWidget *pListView);
void modifier_comptes(char login[],char password[],int role,char cin[],char mdp []);
void supprimer_h(char cin[]);
