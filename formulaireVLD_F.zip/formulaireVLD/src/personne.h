#include <gtk/gtk.h>
typedef struct
{
char cin[20];
char non[20];
char prenom[30];
char date_naissance[30];
char adresse[20];

}Agent;

