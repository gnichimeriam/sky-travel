

void Afficher_Voiture(GtkWidget* treeview1,char*l);
void Afficher_Client(GtkWidget* treeview1,char*l);
int ChercherClient(GtkWidget* treeview1,char*l,char*nom);
int ChercherVoiture(GtkWidget* treeview1,char*l,voiture v);

