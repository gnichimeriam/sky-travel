
void ajouter_voiture( voiture v);
int exist_voiture(char*matricule);
void supprimer_voiture(char*matricule);

