#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"fonction.h"



void
on_repondrebuttongnichi_clicked        (GtkWidget      *objet_graphique,
                               gpointer         user_data)
{


  GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget* p;
        GtkWidget *label;
        gchar* e_mail;
        gchar* objet;
        gchar* date;
        gchar* date_reponse;
 	gchar* reclamation;
 	gchar* reponse;
      

        label=lookup_widget(windowgnichi,"s_rlabelgnichi");
        p=lookup_widget(windowgnichi,"treeviewgnichii");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  
                gtk_tree_model_get (model,&iter,0,&e_mail,1,&date,2,&objet,3,&reclamation,4,&date_reponse,5,reponse,-1);

		gtk_label_set_text(GTK_LABEL(lookup_widget(windowgnichi,"emaillabelgnichi")),e_mail);

		gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowgnichi,"notebook1")));
                gtk_widget_show(lookup_widget(windowgnichi,"confirmerbuttongnichi"));
           	gtk_widget_hide (label);
		}else{
                gtk_widget_show (label);
        }

}

void
on_retourbuttongnichi_clicked          (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
        gtk_widget_show (windowgnichi1);
        gtk_widget_destroy (windowgnichi);
}

void
on_recbuttongnichi_clicked   (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *p;
recl r;
int i;
windowgnichi1=lookup_widget(objet_graphique,"windowgnichi1"); 
gtk_widget_hide (windowgnichi1);
windowgnichi = create_windowgnichi ();
p=lookup_widget(windowgnichi ,"treeviewgnichii");
i=0; 
afficher_reclamation(p,"/home/gnichi/Bureau/projetgnichi30/projetgnichi3/src/reclamations.txt");
gtk_widget_show (windowgnichi);

}

void
on_confirmerbuttongnichi_clicked       (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
recl r;
GtkWidget* label;
        strcpy(r.e_mail,gtk_label_get_text(GTK_LABEL(lookup_widget(objet_graphique,"emaillabelgnichi"))));
        strcpy(r.date,gtk_label_get_text(GTK_LABEL(lookup_widget(objet_graphique,"datelabelgnichi1"))));
    strcpy(r.objet,gtk_label_get_text(GTK_LABEL(lookup_widget(objet_graphique,"objetlabelgnichi1"))));
    strcpy(r.reclamation,gtk_label_get_text(GTK_LABEL(lookup_widget(objet_graphique,"rlabelgnichi1"))));
    		strcpy(r.date_reponse,gtk_entry_get_text(GTK_ENTRY(lookup_widget(objet_graphique,"dentrygnichi"))));
    strcpy(r.reponse,gtk_entry_get_text(GTK_ENTRY(lookup_widget(objet_graphique,"textentrygnichi"))));
        supprimer_reclamation(r.reclamation);
        ajouter_reclamation(r);
        afficher_reclamation(lookup_widget(objet_graphique,"treeviewgnichii"),"/home/gnichi/Bureau/projetgnichi30/projetgnichi3/src/reclamations.txt");
        label=lookup_widget(objet_graphique,"confirmlabelgnichi");
        gtk_widget_show(label);
}


