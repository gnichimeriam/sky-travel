#include <gtk/gtk.h>

typedef struct 
{
char e_mail[30];
char date[30];
char objet[30];
char reclamation[500];
char date_reponse[30];
char reponse[500];

}recl;
  int i,j;
  GtkWidget *windowgnichi;
  GtkWidget *windowgnichi1;

void
on_repondrebuttongnichi_clicked        (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_retourbuttongnichi_clicked          (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_recbuttongnichi_clicked             (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_confirmerbuttongnichi_clicked       (GtkWidget      *objet_graphique,
                                        gpointer         user_data);
