#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include "callbacks.h"
#include"fonction.h"
GtkListStore *adstore;/*creation du modele de type liste*/
GtkTreeViewColumn *adcolumn;/*visualisation des colonnes*/
GtkCellRenderer *cellad;/*afficheur de cellule(text,image..)*/
FILE *f;

void afficher_reclamation(GtkWidget* treeview,char*m)
{

recl r;


        /* Creation du modele */
        adstore = gtk_list_store_new(6,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING
                                    );
      
        f=fopen(m,"r");
while(fscanf(f,"%s : %s : %s :%s :%s :%s \n",r.e_mail,r.date,r.objet,r.reclamation,r.date_reponse,r.reponse)!=EOF)
        {GtkTreeIter pIter;

         /* Creation de la nouvelle ligne */
         gtk_list_store_append(adstore, &pIter);
         /* Mise a jour des donnees */
         gtk_list_store_set(adstore, &pIter,
                            0,r.e_mail,
                            1,r.date,
                            2,r.objet,
                            3,r.reclamation,
                            4,r.date_reponse,
			    5,r.reponse,
                            -1);}
        fclose(f);

	
if(i==0){

	
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("E_MAIL",
                                                            cellad,
                                                            "text", 0,
                                                            NULL);
	
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), adcolumn);

	
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("DATE",
                                                            cellad,
                                                            "text", 1,
                                                            NULL);
	
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("OBJET",
                                                            cellad,
                                                            "text", 2,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("RECLAMATION",
                                                            cellad,
                                                            "text", 3,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), adcolumn);

 cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("DATE_REPONSE",
                                                            cellad,
                                                            "text", 3,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), adcolumn);
 cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("REPONSE",
                                                            cellad,
                                                            "text", 3,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), adcolumn);


	i++;}


 	gtk_tree_view_set_model ( GTK_TREE_VIEW (treeview),
                                  GTK_TREE_MODEL(adstore)  );

}

void ajouter_reclamation( recl r)
{
FILE*f=NULL;
f=fopen("/home/gnichi/Bureau/projetgnichi30/projetgnichi3/src/reclamations.txt","a+");
fprintf(f,"%s : %s :%s :%s :%s :%s \n",r.e_mail,r.date,r.objet,r.reclamation,r.date_reponse,r.reponse);
fclose(f);
}
void supprimer_reclamation(char*e_mail)
{
FILE*f=NULL;
FILE*f1=NULL;
 recl r;
f=fopen("/home/gnichi/Bureau/projetgnichi30/projetgnichi3/src/reclamations.txt","r");

f1=fopen("/home/gnichi/Bureau/projetgnichi30/projetgnichi3/src/ancien.txt","w+");
while(fscanf(f,"%s : %s : %s :%s :%s :%s \n",r.e_mail,r.date,r.objet,r.reclamation,r.date_reponse,r.reponse)!=EOF)
{
if(strcmp(e_mail,r.e_mail)!=0)fprintf(f1,"%s : %s : %s :%s :%s :%s \n",r.e_mail,r.date,r.objet,r.reclamation,r.date_reponse,r.reponse);
}
fclose(f);
fclose(f1);
remove("/home/gnichi/Bureau/projetgnichi30/projetgnichi3/src/reclamations.txt");
rename("/home/gnichi/Bureau/projetgnichi30/projetgnichi3/src/ancien.txt","reclamations.txt");
}

