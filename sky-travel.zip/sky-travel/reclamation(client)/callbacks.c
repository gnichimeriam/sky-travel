#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"


void
on_ajouter_reclbuttong_clicked         (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *cal1;

FILE*f=NULL;
recl r;
int j,m,a,b=1;


cal1=lookup_widget(windowgm1,"calendargm");


strcpy(r.e_mail,gtk_entry_get_text(GTK_ENTRY(lookup_widget(objet_graphique,"e_mailentrygm"))));


gtk_calendar_get_date (GTK_CALENDAR(cal1),
                       &a,
                       &m,
                       &j);
strcpy(r.objet,gtk_entry_get_text(GTK_ENTRY(lookup_widget(objet_graphique,"objetentrygm"))));

strcpy(r.reclamation,gtk_entry_get_text(GTK_ENTRY(lookup_widget(objet_graphique,"recentrygm"))));

f=fopen("reclamations.txt","a+");
fprintf(f,"%s : %d/%d/%d : %s : %s\n",r.e_mail,j,m,a,r.objet,r.reclamation);
fclose(f);

GtkWidget *p;
p=lookup_widget(objet_graphique,"treeviewgm");
afficher_reclamation(p,"reclamations.txt");


}


void
on_retourbuttong_clicked               (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
	gtk_widget_show (windowgm0);
        gtk_widget_destroy (windowgm1);
}


void
on_acceuilbuttongm_clicked             (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *p;
recl r;
int i;
windowgm0=lookup_widget(objet_graphique,"windowgm0"); 
gtk_widget_destroy (windowgm0);
windowgm1 = create_windowgm1 ();
p=lookup_widget(windowgm1 ,"treeviewgm");
i=0; 
afficher_reclamation(p,"reclamations.txt");
gtk_widget_show (windowgm1);
}

