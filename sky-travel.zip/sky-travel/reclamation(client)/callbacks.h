#include <gtk/gtk.h>

typedef struct 
{
char e_mail[30];
char date[30];
char objet[30];
char reclamation[500];

}recl;
  int i,j;
  GtkWidget *windowgm0;
  GtkWidget *windowgm1;

void
on_ajouter_reclbuttong_clicked         (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_retourbuttong_clicked               (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_acceuilbuttongm_clicked             (GtkWidget      *objet_graphique,
                                        gpointer         user_data);
