
#include<stdio.h>
#include<stdlib.h>
#include "callbacks.h"
#include<string.h>
#include"fonction.h"
#include <gtk/gtk.h>
GtkListStore *adstore;/*creation du modele de type liste*/
GtkTreeViewColumn *adcolumn;/*visualisation des colonnes*/
GtkCellRenderer *cellad;/*afficheur de cellule(text,image..)*/
FILE *f;

void afficher_reclamation(GtkWidget* treeview,char*m)
{

recl r;


        /* Creation du modele */
        adstore = gtk_list_store_new(4,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING
                                     
                                    );
        /* Insertion des elements */
        f=fopen(m,"r");
while(fscanf(f,"%s : %s : %s :%s\n",r.e_mail,r.date,r.objet,r.reclamation)!=EOF)
        {GtkTreeIter pIter;

         /* Creation de la nouvelle ligne */
         gtk_list_store_append(adstore, &pIter);
         /* Mise a jour des donnees */
         gtk_list_store_set(adstore, &pIter,
                            0,r.e_mail,
                            1,r.date,
                            2,r.objet,
                            3,r.reclamation,
                            
                            -1);}
        fclose(f);

	
if(i==0){

	/* Creation de la 1er colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("E_MAIL",
                                                            cellad,
                                                            "text", 0,
                                                            NULL);
	/* Ajouter la 1er colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), adcolumn);

	/* Creation de la 2eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("DATE",
                                                            cellad,
                                                            "text", 1,
                                                            NULL);
	/* Ajouter la 2emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("OBJET",
                                                            cellad,
                                                            "text", 2,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("RECLAMATION",
                                                            cellad,
                                                            "text", 3,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), adcolumn);



	i++;}


 	gtk_tree_view_set_model ( GTK_TREE_VIEW (treeview),
                                  GTK_TREE_MODEL(adstore)  );

}

void ajouter_reclamation( recl r){
FILE*f=NULL;
f=fopen("reclamation.txt","a+");
fprintf(f,"%s : %s : %s :%s \n",r.e_mail,r.date,r.objet,r.reclamation);
fclose(f);
}


