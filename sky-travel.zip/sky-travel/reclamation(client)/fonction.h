void ajouter_reclamation( recl r);
void afficher_reclamation(GtkWidget* treeview,char*m);
