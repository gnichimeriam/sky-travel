

void Afficher_Voiture(GtkWidget* treeview1,char*l);
void Afficher_Client(GtkWidget* treeview1,char*l);
int ChercherClient(GtkWidget* treeview1,char*l,char*nom);
int ChercherVoiture(GtkWidget* treeview1,char*l,voiture v);
void ajouter_voiture( voiture v);
int exist_voiture(char*matricule);
void supprimer_voiture(char*matricule);
